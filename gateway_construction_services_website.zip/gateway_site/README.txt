GATEWAY CONSTRUCTION SERVICES, INC. — WEBSITE STARTER

CONTENTS
- index.html: responsive public-facing site, English/Spanish text toggle, job listing, contact information, WhatsApp link, status-portal preview, and contact-form preview.
- admin.html: staff dashboard layout preview.

BUSINESS DETAILS INCLUDED
- US phone: +1 573-422-5970
- Mexico contact / associated recruiter (provided by user; affiliation not independently verified): +52 81 1638 6606
- Email: gatewayconstructionsserviceinc@proton.me
- Job: Construction Laborer
- Wage supplied for this draft: $30.06 USD/hour
- Schedule: 40 hours/week, 7:00 AM–3:30 PM; some overtime and weekends may be required
- Openings: 3
- Experience: none required
- Physical requirement: lift 50 lb (about 22.7 kg); random post-hire drug testing may occur
- Worksite: 4826–4876 Fountain Avenue, St. Louis, MO 63113, USA
- Employer location provided: St. Louis, MO 63141, USA

IMPORTANT LIMITATIONS
This is a front-end prototype. The contact form does not transmit or store submissions. The application-status form does not authenticate credentials or retrieve an actual status. admin.html is only a visual preview, not a secure login or database. Do not collect real candidate data until secure authentication, backend/database, access controls, privacy notice, and data retention protections are configured.

BEFORE PUBLISHING
1. Confirm all company details and that the job description, wage, worksite, and terms match the employer's official job order.
2. Add a suitable privacy notice and any required business/legal disclosures.
3. Connect a secure form service/backend for contact and application submissions.
4. Implement secure staff authentication and role-based permissions.
5. Implement application folio + password authentication and status lookup through the backend. Store password hashes only; never store plaintext passwords.
6. Test phone and WhatsApp links, mobile layout, form validation, accessibility, and security.

PUBLISHING THE VISUAL PROTOTYPE
You can upload the contents of this folder to a static host such as Netlify for a public visual preview. A static deployment will NOT make the forms, status lookup, or admin panel functional. The site uses externally hosted Unsplash photos, so those images require an internet connection.
